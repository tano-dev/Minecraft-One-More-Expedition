teleport @s ^ ^ ^
