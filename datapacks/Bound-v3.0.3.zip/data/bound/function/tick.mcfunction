execute as @a run function bound:player
