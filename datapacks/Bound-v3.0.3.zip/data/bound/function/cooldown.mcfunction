kill @e[type=armor_stand, tag=bound_stand]
