advancement grant @s only bound:visible/bound3
