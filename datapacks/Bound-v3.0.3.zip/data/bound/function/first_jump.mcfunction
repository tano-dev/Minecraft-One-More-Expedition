tag @s add bound.first_jump
