
$data modify storage eden:settings keepinv merge value {\
    keepinv_type:'$(keepinv_type)',\
    equip_dmg:'$(equip_dmg)',\
    exp_loss:'$(exp_loss)',\
    grave_duration: $(grave_duration),\
    grave_timer:'$(grave_timer)',\
    player_head_drop:'$(player_head_drop)',\
    non_droppable_tag_list:'$(non_droppable_tag_list)',\
    grave_status:'$(grave_status)',\
    grave_type:'$(grave_type)'\
}

$data modify storage eden:settings keepinv.equip_dmg_amount_initial set value $(equip_dmg_amount)
execute store result storage eden:settings keepinv.equip_dmg_amount float 0.01 run data get storage eden:settings keepinv.equip_dmg_amount_initial

$data modify storage eden:settings keepinv.exp_loss_amount_initial set value $(exp_loss_amount)
execute store result storage eden:settings keepinv.exp_loss_amount float 0.01 run data get storage eden:settings keepinv.exp_loss_amount_initial

$data modify storage eden:settings keepinv.player_head_drop_chance_initial set value $(player_head_drop_chance)
execute store result storage eden:settings keepinv.player_head_drop_chance float 0.01 run data get storage eden:settings keepinv.player_head_drop_chance_initial

execute store result score $grave_duration keepinv.grave.duration run data get storage eden:settings keepinv.grave_duration 60

execute if data storage eden:settings keepinv{keepinv_type:"taglist"} run data modify storage eden:settings keepinv.keepinv_type_taglist_initial set value "true"
execute if data storage eden:settings keepinv{keepinv_type:"taglist"} run data modify storage eden:settings keepinv.keepinv_type_hotbar_initial set value "false"
execute if data storage eden:settings keepinv{keepinv_type:"taglist"} run data modify storage eden:settings keepinv.keepinv_type_none_initial set value "false"

execute if data storage eden:settings keepinv{keepinv_type:"hotbar"} run data modify storage eden:settings keepinv.keepinv_type_taglist_initial set value "false"
execute if data storage eden:settings keepinv{keepinv_type:"hotbar"} run data modify storage eden:settings keepinv.keepinv_type_hotbar_initial set value "true"
execute if data storage eden:settings keepinv{keepinv_type:"hotbar"} run data modify storage eden:settings keepinv.keepinv_type_none_initial set value "false"

execute if data storage eden:settings keepinv{keepinv_type:"none"} run data modify storage eden:settings keepinv.keepinv_type_taglist_initial set value "false"
execute if data storage eden:settings keepinv{keepinv_type:"none"} run data modify storage eden:settings keepinv.keepinv_type_hotbar_initial set value "false"
execute if data storage eden:settings keepinv{keepinv_type:"none"} run data modify storage eden:settings keepinv.keepinv_type_none_initial set value "true"

execute if data storage eden:settings keepinv{equip_dmg:"enabled"} run data modify storage eden:settings keepinv.equip_dmg_initial set value "false"
execute unless data storage eden:settings keepinv{equip_dmg:"enabled"} run data modify storage eden:settings keepinv.equip_dmg_initial set value "true"

execute if data storage eden:settings keepinv{exp_loss:"enabled"} run data modify storage eden:settings keepinv.exp_loss_initial set value "false"
execute unless data storage eden:settings keepinv{exp_loss:"enabled"} run data modify storage eden:settings keepinv.exp_loss_initial set value "true"

execute if data storage eden:settings keepinv{grave_timer:"world_time"} run data modify storage eden:settings keepinv.grave_timer_world_time_initial set value "true"
execute unless data storage eden:settings keepinv{grave_timer:"world_time"} run data modify storage eden:settings keepinv.grave_timer_world_time_initial set value "false"

execute if data storage eden:settings keepinv{grave_status:"enabled"} run data modify storage eden:settings keepinv.grave_status_initial set value "false"
execute unless data storage eden:settings keepinv{grave_status:"enabled"} run data modify storage eden:settings keepinv.grave_status_initial set value "true"

execute if data storage eden:settings keepinv{player_head_drop:"enabled"} run data modify storage eden:settings keepinv.player_head_drop_initial set value "false"
execute unless data storage eden:settings keepinv{player_head_drop:"enabled"} run data modify storage eden:settings keepinv.player_head_drop_initial set value "true"

execute if data storage eden:settings keepinv{grave_type:"random"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"false",\
    grave_type_skull_initial:"false",\
    grave_type_chest_initial:"false",\
    grave_type_bundle_initial:"false",\
    grave_type_tombstone_initial:"false",\
    grave_type_player_head_initial:"false"\
}

execute if data storage eden:settings keepinv{grave_type:"candle"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"true",\
    grave_type_skull_initial:"false",\
    grave_type_chest_initial:"false",\
    grave_type_bundle_initial:"false",\
    grave_type_tombstone_initial:"false",\
    grave_type_player_head_initial:"false",\
}

execute if data storage eden:settings keepinv{grave_type:"skull"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"false",\
    grave_type_skull_initial:"true",\
    grave_type_chest_initial:"false",\
    grave_type_bundle_initial:"false",\
    grave_type_tombstone_initial:"false",\
    grave_type_player_head_initial:"false"\
}

execute if data storage eden:settings keepinv{grave_type:"chest"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"false",\
    grave_type_skull_initial:"false",\
    grave_type_chest_initial:"true",\
    grave_type_bundle_initial:"false",\
    grave_type_tombstone_initial:"false",\
    grave_type_player_head_initial:"false"\
}

execute if data storage eden:settings keepinv{grave_type:"bundle"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"false",\
    grave_type_skull_initial:"false",\
    grave_type_chest_initial:"false",\
    grave_type_bundle_initial:"true",\
    grave_type_tombstone_initial:"false",\
    grave_type_player_head_initial:"false"\
}

execute if data storage eden:settings keepinv{grave_type:"tombstone"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"false",\
    grave_type_skull_initial:"false",\
    grave_type_chest_initial:"false",\
    grave_type_bundle_initial:"false",\
    grave_type_tombstone_initial:"true",\
    grave_type_player_head_initial:"false"\
}

execute if data storage eden:settings keepinv{grave_type:"player_head"} run data modify storage eden:settings keepinv merge value {\
    grave_type_candle_initial:"false",\
    grave_type_skull_initial:"false",\
    grave_type_chest_initial:"false",\
    grave_type_bundle_initial:"false",\
    grave_type_tombstone_initial:"false",\
    grave_type_player_head_initial:"true"\
}

execute if data storage eden:settings keepinv{grave_duration:0} run \
    tellraw @s [{"bold":false,"color":"#89CFF0","italic":false,"text":"▊ "},{"bold":false,"color":"white","italic":false,"text":"Setting the Grave Duration to 0 minutes will prevent graves from despawning automatically. Keep in mind that having a large number of graves loaded at once may lead to lag."}]