advancement revoke @s only keepinv:grave/left_click
advancement revoke @s only keepinv:grave/right_click

data remove storage eden:temp keepinv.grave
data modify storage eden:temp keepinv.grave.uuid set from entity @s UUID

loot spawn ~ ~ ~ loot keepinv:gameplay/player_head
data modify storage eden:temp keepinv.grave.name set from entity @n[type=item,nbt={Item:{id:"minecraft:player_head"}},distance=..1] Item.components.minecraft:profile.name
kill @n[type=item,nbt={Item:{id:"minecraft:player_head"}},distance=..1]

execute as @e[type=minecraft:interaction,tag=keepinv.grave.interaction,distance=..16] if data entity @s attack at @s run function keepinv:grave/player_interaction/exec with storage eden:temp keepinv.grave
execute as @e[type=minecraft:interaction,tag=keepinv.grave.interaction,distance=..16] if data entity @s interaction at @s run function keepinv:grave/player_interaction/exec with storage eden:temp keepinv.grave

execute if data storage eden:temp keepinv.grave{is_owner:true} run advancement grant @s only eden:adventure/grave_robber
execute if data storage eden:temp keepinv.grave{is_owner:true} run advancement grant @s only eden:adventure/six_feet_under_briefly recovered_own_grave

execute as @e[type=minecraft:interaction,tag=keepinv.grave.interaction,distance=..16] if data entity @s attack at @s run data remove entity @s attack
execute as @e[type=minecraft:interaction,tag=keepinv.grave.interaction,distance=..16] if data entity @s interaction at @s run data remove entity @s interaction