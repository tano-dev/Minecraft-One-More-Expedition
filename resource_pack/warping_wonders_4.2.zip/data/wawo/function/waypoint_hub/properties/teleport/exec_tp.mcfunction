$execute unless data storage eden:database waypoints.hubs.$(id).profile{name:"$(executor)"} \
    if data storage eden:database waypoints.hubs.$(id){announcement:"enabled"} run \
        playsound minecraft:entity.chicken.egg neutral $(owner) ~ ~ ~ .5 2

$execute unless data storage eden:database waypoints.hubs.$(id).profile{name:"$(executor)"} \
    if data storage eden:database waypoints.hubs.$(id){announcement:"enabled"} run \
        tellraw $(owner) [\
            {"bold":true,"color":"dark_purple","italic":false,"text":"▊ "},\
            {"bold":false,"color":"white","italic":false,"text":"$(executor) "},\
            {"bold":false,"color":"white","fallback":"teleported to your Waypoint:","italic":false,"translate":"message.warping_wonders.waypoint_hub.visitor"},\
            {"bold":false,"color":"$(color)","italic":false,"text":" $(name)"},\
            {"bold":false,"color":"white","italic":false,"text":"."}\
        ]

$execute if data storage eden:settings warping_wonders.waypoint_hub{mob_teleport:"enabled"} \
    as @e[nbt={leash: {UUID:$(uuid)}}] \
    in $(dimension) positioned $(x) $(y) $(z) \
        run tp @s $(relative_coords)

$execute if data storage eden:settings warping_wonders.waypoint_hub{mob_teleport:"enabled"} \
    as @e[type=#wawo:is_pet,distance=..24] \
    if data entity @s {Owner:$(uuid)} \
    unless data entity @s {Sitting:1b} \
    in $(dimension) positioned $(x) $(y) $(z) \
        run tp @s $(relative_coords)

$execute at @s unless predicate wawo:entity/is_riding in $(dimension) positioned $(x) $(y) $(z) run tp @s $(relative_coords)
$execute at @s if predicate wawo:entity/is_riding in $(dimension) positioned $(x) $(y) $(z) on vehicle run tp @s $(relative_coords)

execute at @s run playsound minecraft:entity.enderman.teleport neutral @a ~ ~ ~ .5 0.5
particle minecraft:reverse_portal ~ ~.5 ~ .3 .7 .3 0 100

$experience add @s -$(exp_cost) levels
$tellraw @s [\
    {"bold":true,"color":"dark_purple","italic":false,"text":"▊ "},\
    {"bold":false,"color":"white","fallback":"Teleported to","italic":false,"translate":"message.warping_wonders.waypoint_hub.teleport_to"},\
    {"bold":false,"color":"$(color)","italic":false,"text":" $(name)"},\
    {"bold":false,"color":"white","italic":false,"text":"."}\
]

$execute in $(dimension) positioned $(x) $(y) $(z) as @n[type=item_display,distance=..6,tag=wawo.waypoint_hub.display] at @s run setblock ~ ~-1 ~ minecraft:petrified_oak_slab[type=top]
$execute in $(dimension) positioned $(x) $(y) $(z) as @n[type=item_display,distance=..6,tag=wawo.waypoint_hub.display] at @s run setblock ~ ~-1 ~ minecraft:petrified_oak_slab[type=double]

$execute in $(dimension) positioned $(x) $(y) $(z) run forceload remove ~ ~
data remove storage eden:temp waypoint.teleport
